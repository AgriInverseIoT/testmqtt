import mqtt, { MqttClient } from 'mqtt';
import fs from 'fs';
import path from 'path';

interface Message {
    topic: string;
    message: string;
    timestamp: Date;
}

class MqttService {
    private client: MqttClient | null = null;
    private messages: Message[] = [];
    private topic: string;
    private isConnected = false;

    constructor() {
        // Load config from environment
        this.topic = process.env.AWS_IOT_TOPIC || 'fert/cmd';
        this.connect();
    }

    private connect(): void {
        const endpoint = process.env.AWS_IOT_ENDPOINT;
        // Generate unique client ID to avoid conflicts
        const clientId = `${process.env.AWS_IOT_CLIENT_ID || 'mqtt-client'}-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;

        const certsPath = path.join(__dirname, '../certs');
        const certFile = path.join(certsPath, 'certificate.pem.crt');
        const keyFile = path.join(certsPath, 'private.pem.key');
        const caFile = path.join(certsPath, 'AmazonRootCA1.pem');

        // Check if certificates exist
        const certsExist = fs.existsSync(certFile) &&
            fs.existsSync(keyFile) &&
            fs.existsSync(caFile);

        if (!endpoint || endpoint.includes('YOUR_ENDPOINT')) {
            console.log('⚠️  AWS IoT not configured. Please update .env file with:');
            console.log('   AWS_IOT_ENDPOINT=your-endpoint.iot.region.amazonaws.com');
            console.log('');
            return;
        }

        if (!certsExist) {
            console.log('⚠️  Certificates not found. Please add to /certs folder:');
            console.log('   - certificate.pem.crt');
            console.log('   - private.pem.key');
            console.log('   - AmazonRootCA1.pem');
            console.log('');
            return;
        }

        const brokerUrl = `mqtts://${endpoint}:8883`;
        console.log(`🔌 Connecting to AWS IoT: ${endpoint}`);
        console.log(`   Client ID: ${clientId}`);

        this.client = mqtt.connect(brokerUrl, {
            clientId,
            clean: true,
            connectTimeout: 10000,
            keepalive: 60,
            reconnectPeriod: 5000,
            cert: fs.readFileSync(certFile),
            key: fs.readFileSync(keyFile),
            ca: fs.readFileSync(caFile),
            protocol: 'mqtts',
            protocolVersion: 4,
        });

        this.client.on('connect', () => {
            console.log('✅ Connected to AWS IoT');
            this.isConnected = true;
            this.subscribe();
        });

        this.client.on('message', (topic, payload) => {
            const message = payload.toString();
            console.log(`📩 Received: [${topic}] ${message}`);
            this.messages.push({
                topic,
                message,
                timestamp: new Date(),
            });
        });

        this.client.on('error', (err) => {
            console.error('❌ MQTT Error:', err.message);
            this.isConnected = false;
        });

        this.client.on('close', () => {
            console.log('🔌 Disconnected from AWS IoT');
            this.isConnected = false;
        });

        this.client.on('disconnect', (packet: any) => {
            console.log('⚠️  Broker requested disconnect:', packet);
        });

        this.client.on('offline', () => {
            console.log('📴 Client went offline');
        });

        this.client.on('reconnect', () => {
            console.log('🔄 Reconnecting to AWS IoT...');
        });
    }

    private subscribe(): void {
        if (!this.client) return;

        this.client.subscribe(this.topic, { qos: 1 }, (err) => {
            if (err) {
                console.error(`❌ Failed to subscribe to ${this.topic}:`, err.message);
            } else {
                console.log(`📡 Subscribed to topic: ${this.topic}`);
            }
        });
    }

    publish(message: string): Promise<void> {
        return new Promise((resolve, reject) => {
            if (!this.client || !this.isConnected) {
                reject(new Error('Not connected to AWS IoT. Check configuration and certificates.'));
                return;
            }

            this.client.publish(this.topic, message, { qos: 1 }, (err) => {
                if (err) {
                    console.error('❌ Publish failed:', err.message);
                    reject(err);
                } else {
                    console.log(`📤 Published to [${this.topic}]: ${message}`);
                    resolve();
                }
            });
        });
    }

    getMessages(): Message[] {
        return this.messages;
    }

    clearMessages(): void {
        this.messages = [];
    }

    getTopic(): string {
        return this.topic;
    }

    getStatus(): { connected: boolean; topic: string; endpoint: string | undefined } {
        return {
            connected: this.isConnected,
            topic: this.topic,
            endpoint: process.env.AWS_IOT_ENDPOINT,
        };
    }
}

export const mqttService = new MqttService();
