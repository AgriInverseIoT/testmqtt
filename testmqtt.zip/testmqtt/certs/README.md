# AWS IoT Certificates

Place your AWS IoT certificate files here:

| File | Description |
|------|-------------|
| `certificate.pem.crt` | Device certificate from AWS IoT |
| `private.pem.key` | Private key from AWS IoT |
| `AmazonRootCA1.pem` | Amazon Root CA certificate |

## Getting these files

1. Go to **AWS IoT Console** → **Manage** → **Things**
2. Create a new thing or select existing
3. Create/download certificates
4. Download the Root CA from: https://www.amazontrust.com/repository/AmazonRootCA1.pem

## After adding files

Update `.env` with your AWS IoT endpoint:
```
AWS_IOT_ENDPOINT=xxxxxx-ats.iot.us-east-1.amazonaws.com
```
