#define TINY_GSM_MODEM_A7670
#define SerialMon Serial
#define SerialAT Serial1
#define TINY_GSM_DEBUG SerialMon
#define GSM_PIN ""

#include <TinyGsmClient.h>
#include <ArduinoJson.h>
#include <TimeLib.h>

#include "certificate.h"
#include "privatekey.h"
#include "root_ca.h"
#include "awscerts.h"

// ================= LoRa =================
#include <SPI.h>
#include <LoRa.h>

// ---------- Device Identifier ----------
#define DEVICE_ID "DId1"

// ---------- LoRa ----------
#define LORA_SS   5
#define LORA_RST  14
#define LORA_DIO0 26
#define LORA_FREQ 433E6

#define NODE1_ID  0xAA
#define NODE2_ID  0xCC
#define NODE3_ID  0xBB
#define NODE4_ID  0xD1
#define NODE5_ID  0xD2
#define NODE6_ID  0xD3
#define NODE7_ID  0xD4
#define NODE8_ID  0xD5

// ================= GSM MODEM =================
TinyGsm modem(SerialAT);

uint32_t lastReconnectAttempt = 0;

// ---------- Timing ----------
unsigned long lastNode1 = 0;
unsigned long lastNode2 = 0;
const unsigned long timeoutMs = 10000;

// ---------- JSON Buffers ----------
DynamicJsonDocument node1Data(1024);
DynamicJsonDocument node2Data(1024);
bool node1Received = false;
bool node2Received = false;

// ---------- Forward ----------
void sendLoRaCommand(int targetNode, const String &cmd);
void handleLoRaAck(const String &payload);
void sendMergedJSON();

// =========================================================
//                  MQTT CALLBACK (COMMANDS)
// =========================================================
void mqtt_callback(const char* topic, const uint8_t* payload, uint32_t len) {

  String msg;
  for (uint32_t i = 0; i < len; i++) msg += (char)payload[i];

  Serial.println("📥 MQTT CMD:");
  Serial.println(msg);

  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, msg)) return;

  if (doc["type"] == "command_broadcast") {
    String cmd = doc["command"];
    int node   = doc["node"];
    String dev = doc["device"];

    if (dev == DEVICE_ID) {
      sendLoRaCommand(node, cmd);
    }
  }
}

// =========================================================
//                  MQTT CONNECT
// =========================================================
bool mqtt_connect() {
  if (!modem.mqtt_connect(0, broker, broker_port, client_id)) {
    Serial.println("❌ MQTT connect failed");
    return false;
  }

  modem.mqtt_set_callback(mqtt_callback);
  modem.mqtt_subscribe(0, subscribe_topic);

  Serial.println("✅ MQTT connected");
  return true;
}

// =========================================================
//                  SEND LORA COMMAND
// =========================================================
void sendLoRaCommand(int targetNode, const String &cmd) {
  uint8_t dest;

  switch (targetNode) {
    case 4: dest = NODE4_ID; break;
    case 5: dest = NODE5_ID; break;
    case 6: dest = NODE6_ID; break;
    case 7: dest = NODE7_ID; break;
    case 8: dest = NODE8_ID; break;
    default: return;
  }

  StaticJsonDocument<128> doc;
  doc["cmd"] = cmd;
  doc["to"]  = targetNode;

  String out;
  serializeJson(doc, out);

  LoRa.beginPacket();
  LoRa.write(dest);
  LoRa.write(NODE3_ID);
  LoRa.print(out);
  LoRa.endPacket();

  Serial.println("📡 LoRa CMD sent");
}

// =========================================================
//                  HANDLE ACK → MQTT
// =========================================================
void handleLoRaAck(const String &payload) {
  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, payload)) return;

  if (doc["ack"] == true) {
    String out;
    serializeJson(doc, out);
    modem.mqtt_publish(0, publish_topic, out.c_str());
  }
}

// =========================================================
//                  SEND MERGED JSON → MQTT
// =========================================================
void sendMergedJSON() {
  DynamicJsonDocument doc(2048);

  doc["FId"] = "cmifx3urt0001txd45bosa4uq";
  doc["Id"]  = "M1";
  doc["UId"] = "35";
  doc["BId"] = "cmifx3v000003txd41yu4nyzj";
  doc["DId"] = "D1";

if (node2Received && millis() - lastNode2 < timeoutMs) {
    for (JsonPair kv : node2Data.as<JsonObject>()) {
      doc[kv.key()] = kv.value();
    }
  } else {
    const char* keys[] = {
      "CO2","WS","par","CT","CH","N","P","K","ST","SM","EC","Ph"
      "F1","F2","F3","F4","F5","F6","F7","F8","NIR","Clear"
    };
    for (auto k : keys) doc[k] = 0;
  }

  // Node 1 nested data
  JsonObject n1 = doc.createNestedObject("Node1");
  if (node1Received && millis() - lastNode1 < timeoutMs) {
    for (JsonPair kv : node1Data.as<JsonObject>()) {
      n1[kv.key()] = kv.value();
    }
  } else {
    n1["N"] = 0;
    n1["P"] = 0;
    n1["K"] = 0;
    n1["ST"] = 0;
    n1["SM"] = 0;
    n1["EC"] = 0;
  }
  String out;
  serializeJson(doc, out);

  modem.mqtt_publish(0, publish_topic, out.c_str());
  Serial.println("📤 MQTT published merged JSON");
}

// =========================================================
//                      SETUP
// =========================================================
void setup() {
  SerialMon.begin(115200);

  SerialAT.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);
  delay(3000);

  modem.init();
  modem.waitForNetwork();
  modem.gprsConnect(apn, gprsUser, gprsPass);

  modem.mqtt_begin(true);
  modem.mqtt_set_certificate(root_ca, certificate, privateKey);
  mqtt_connect();

  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);
  LoRa.begin(LORA_FREQ);
}

// =========================================================
//                      LOOP
// =========================================================
void loop() {

  if (!modem.mqtt_connected()) {
    uint32_t now = millis();
    if (now - lastReconnectAttempt > 10000) {
      lastReconnectAttempt = now;
      mqtt_connect();
    }
    return;
  }

  modem.mqtt_handle();

int packetSize = LoRa.parsePacket();
  if (packetSize) {
    uint8_t dest = LoRa.read();
    uint8_t src  = LoRa.read();
    String payload = "";
    while (LoRa.available()) payload += (char)LoRa.read();

    Serial.printf("📥 LoRa packet from 0x%X (%d bytes)\n", src, payload.length());

    payload.trim();
    int jsonStart = payload.indexOf('{');
    if (jsonStart > 0) payload = payload.substring(jsonStart);
    if (payload.charAt(payload.length() - 1) != '}') {
      Serial.println("⚠️ Incomplete JSON received, skipping.");
      return;
    }

    DynamicJsonDocument tempDoc(1024);
    DeserializationError err = deserializeJson(tempDoc, payload);

    if (err) {
      Serial.print("❌ JSON parse failed: ");
      Serial.println(err.f_str());
      Serial.println(payload);
    } else {
      Serial.println("✅ JSON parsed successfully");
      if (src == NODE1_ID) {
        node1Data = tempDoc;
        node1Received = true;
        lastNode1 = millis();
      } else if (src == NODE2_ID) {
        node2Data = tempDoc;
        node2Received = true;
        lastNode2 = millis();
      } else {
        handleLoRaAck(payload);   // Check for ACKs from other nodes
      }
    }
  }

  // ----- Periodic Send -----
  static unsigned long lastSend = 0;
  if (millis() - lastSend >= 10000) {   // every 10 s
    lastSend = millis();
    if (node1Received || node2Received) {
      sendMergedJSON();
    }
  }
}