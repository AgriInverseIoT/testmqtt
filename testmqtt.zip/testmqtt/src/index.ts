import 'dotenv/config';
import express from 'express';
import path from 'path';
import { mqttService } from './mqtt.service';

const app = express();
const PORT = 3001;

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Get connection status
app.get('/status', (req, res) => {
    res.json(mqttService.getStatus());
});

// Publish a message to MQTT
app.post('/publish', async (req, res) => {
    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        await mqttService.publish(message);
        res.json({
            success: true,
            topic: mqttService.getTopic(),
            message
        });
    } catch (error: any) {
        res.status(500).json({ error: error.message || 'Failed to publish message' });
    }
});

// Get all received messages
app.get('/messages', (req, res) => {
    const messages = mqttService.getMessages();
    res.json({
        topic: mqttService.getTopic(),
        count: messages.length,
        messages
    });
});

// Clear all messages
app.delete('/messages', (req, res) => {
    mqttService.clearMessages();
    res.json({ success: true, message: 'Messages cleared' });
});

app.listen(PORT, () => {
    console.log(`\n🚀 Server running at http://localhost:${PORT}`);
    console.log(`📝 Test UI available at http://localhost:${PORT}`);
    console.log(`\n--- API Endpoints ---`);
    console.log(`GET  /status    - Connection status`);
    console.log(`POST /publish   - Send a message`);
    console.log(`GET  /messages  - Get received messages`);
    console.log(`DELETE /messages - Clear messages\n`);
});
